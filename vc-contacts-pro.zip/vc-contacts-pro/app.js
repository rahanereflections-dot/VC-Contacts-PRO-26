/* ═══════════════════════════════════════════
   app.js  –  VC Contacts PRO Main Application
   ═══════════════════════════════════════════ */

'use strict';

/* ─────────────────────────────────────────
   STATE
   ───────────────────────────────────────── */
const State = {
  contacts:       [],
  filtered:       [],
  currentPage:    'scan',
  editingId:      null,        // contact id being edited
  detailId:       null,        // contact id in detail view
  cameraStream:   null,
  bulkMode:       false,
  selected:       new Set(),
  searchQuery:    '',
  filterCategory: 'All',
};

/* ─────────────────────────────────────────
   DOM SHORTCUTS
   ───────────────────────────────────────── */
const $ = id => document.getElementById(id);
const qsa = sel => document.querySelectorAll(sel);

/* ─────────────────────────────────────────
   AVATAR UTILITIES
   ───────────────────────────────────────── */
function avatarColor(name) {
  let h = 0;
  for (const ch of (name||'A')) h = (h*31 + ch.charCodeAt(0)) & 0xFFFFFF;
  return `av-${h % 8}`;
}

function avatarLetter(name) {
  return (name||'?').trim().charAt(0).toUpperCase();
}

function categoryBadgeClass(cat) {
  const map = {
    'Business':'badge-business','Education':'badge-education',
    'Medical':'badge-medical','Government':'badge-government',
    'Personal':'badge-personal','Services':'badge-services'
  };
  return map[cat] || 'badge-default';
}

function categoryColor(cat, idx) {
  const COLORS = ['#2E7D32','#1565C0','#AD1457','#E65100','#4527A0','#00695C','#558B2F','#C62828'];
  return COLORS[idx % COLORS.length];
}

/* ─────────────────────────────────────────
   NAVIGATION
   ───────────────────────────────────────── */
function navigateTo(page) {
  if (State.currentPage === page) return;

  // Stop camera if leaving scan page
  if (State.currentPage === 'scan') stopCamera();

  State.currentPage = page;

  qsa('.page').forEach(p => p.classList.remove('active'));
  qsa('.nav-item').forEach(n => n.classList.remove('active'));

  const pageEl = $(`page-${page}`);
  if (pageEl) pageEl.classList.add('active');

  const navEl = document.querySelector(`.nav-item[data-page="${page}"]`);
  if (navEl) navEl.classList.add('active');

  // FAB only on contacts
  const fab = $('fab');
  if (fab) fab.style.display = page === 'contacts' ? 'flex' : 'none';

  if (page === 'contacts')   renderContacts();
  if (page === 'stats')      renderStats();
  if (page === 'categories') renderCategories();
}

/* ─────────────────────────────────────────
   CAMERA MODULE
   ───────────────────────────────────────── */
async function startCamera() {
  const video   = $('cameraVideo');
  const overlay = $('cameraOverlay');
  const guides  = $('cameraGuides');

  try {
    State.cameraStream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } }
    });
    video.srcObject = State.cameraStream;
    video.style.display = 'block';
    overlay.style.display = 'none';
    guides.style.display  = 'block';
    $('btnCapture').disabled = false;
    $('btnRetake').style.display = 'none';
  } catch (err) {
    console.error('Camera error:', err);
    overlay.innerHTML = `
      <span class="cam-icon">🚫</span>
      <span class="cam-hint">Camera access denied.<br>Use "Upload Image" or type text manually.</span>
    `;
    $('btnCapture').disabled = true;
  }
}

function stopCamera() {
  if (State.cameraStream) {
    State.cameraStream.getTracks().forEach(t => t.stop());
    State.cameraStream = null;
  }
  const video = $('cameraVideo');
  if (video) video.srcObject = null;
}

function captureFrame() {
  const video    = $('cameraVideo');
  const canvas   = $('captureCanvas');
  const preview  = $('capturedPreview');

  if (!video || !video.videoWidth) { showToast('Camera not ready', 'error'); return; }

  canvas.width  = video.videoWidth;
  canvas.height = video.videoHeight;
  canvas.getContext('2d').drawImage(video, 0, 0);

  const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
  preview.src = dataUrl;
  preview.style.display = 'block';

  // Hide video, show retake
  video.style.display = 'none';
  $('cameraOverlay').style.display = 'none';
  $('cameraGuides').style.display  = 'none';
  $('btnRetake').style.display     = 'inline-flex';
  $('btnCapture').disabled         = true;

  // Show manual text area with hint
  $('rawTextContainer').style.display = 'block';
  $('rawCardText').placeholder = 'Card captured! Type or paste the text from the card here to extract contact info…';
  showToast('Image captured! Enter card text to extract contacts.', 'info', 4000);
}

function retakePhoto() {
  $('capturedPreview').style.display = 'none';
  $('capturedPreview').src = '';
  $('cameraVideo').style.display = 'block';
  $('cameraOverlay').style.display = 'flex';
  $('cameraGuides').style.display  = 'block';
  $('btnRetake').style.display = 'none';
  $('btnCapture').disabled     = false;
  $('rawCardText').value = '';
  hideContactForm();
}

function handleGalleryUpload(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = ev => {
    const preview = $('capturedPreview');
    preview.src           = ev.target.result;
    preview.style.display = 'block';
    stopCamera();
    $('cameraVideo').style.display    = 'none';
    $('cameraOverlay').style.display  = 'none';
    $('cameraGuides').style.display   = 'none';
    $('btnRetake').style.display      = 'inline-flex';
    $('btnCapture').disabled          = true;
    $('rawTextContainer').style.display = 'block';
    $('rawCardText').placeholder = 'Image loaded! Type or paste the text from the card…';
    showToast('Image loaded! Enter card text to extract contacts.', 'info', 4000);
  };
  reader.readAsDataURL(file);
  e.target.value = '';
}

/* ─────────────────────────────────────────
   EXTRACTION
   ───────────────────────────────────────── */
function extractAndShowForm() {
  const raw = ($('rawCardText').value || '').trim();
  if (!raw) { showToast('Please enter some card text first.', 'error'); return; }

  const contact = extractContactData(raw);
  const conf    = extractionConfidence(contact);

  showContactForm(contact, null);
  showToast(`Extracted ${conf}% fields filled.`, conf >= 60 ? 'success' : 'info');
}

/* ─────────────────────────────────────────
   CONTACT FORM
   ───────────────────────────────────────── */
function showContactForm(contact = {}, editId = null) {
  State.editingId = editId;

  $('formTitle').textContent = editId ? 'Edit Contact' : 'New Contact';

  // Populate fields
  const fields = ['name','phone','email','company','designation','address','website'];
  fields.forEach(f => {
    const el = $(`field-${f}`);
    if (el) el.value = contact[f] || '';
  });

  // Category select
  populateCategorySelects();
  const catEl = $('field-category');
  if (catEl) catEl.value = contact.category || 'Business';

  // Confidence bar
  const conf = extractionConfidence(contact);
  const bar  = $('confidenceFill');
  if (bar) { bar.style.width = conf + '%'; bar.parentElement.title = `${conf}% complete`; }

  $('contactFormSection').style.display = 'block';
  $('contactFormSection').scrollIntoView({ behavior: 'smooth', block: 'start' });

  // Duplicate check on phone/email input
  ['field-phone','field-email'].forEach(id => {
    const el = $(id);
    if (el) {
      el.addEventListener('blur', checkDuplicate, { once: false });
    }
  });
}

function hideContactForm() {
  $('contactFormSection').style.display = 'none';
  State.editingId = null;
}

function populateCategorySelects() {
  const cats = getCategories();
  const selects = document.querySelectorAll('.category-select');
  selects.forEach(sel => {
    const current = sel.value;
    sel.innerHTML = cats.map(c => `<option value="${c}">${c}</option>`).join('');
    if (current && cats.includes(current)) sel.value = current;
  });
}

async function checkDuplicate() {
  const phone = ($('field-phone').value || '').trim();
  const email = ($('field-email').value || '').trim();
  if (!phone && !email) { hideDupWarning(); return; }

  const dup = await isDuplicate(
    phone ? phone.replace(/\D/g,'') : null,
    email || null
  );

  if (dup && !State.editingId) {
    $('dupWarning').style.display = 'flex';
  } else {
    hideDupWarning();
  }
}

function hideDupWarning() {
  const el = $('dupWarning');
  if (el) el.style.display = 'none';
}

async function saveContact() {
  const contact = {
    name:        $('field-name').value.trim(),
    phone:       $('field-phone').value.trim(),
    email:       $('field-email').value.trim(),
    company:     $('field-company').value.trim(),
    designation: $('field-designation').value.trim(),
    address:     $('field-address').value.trim(),
    website:     $('field-website').value.trim(),
    category:    $('field-category').value || 'Business',
  };

  if (!contact.name && !contact.phone && !contact.email) {
    showToast('Please fill at least Name, Phone, or Email.', 'error');
    return;
  }

  try {
    if (State.editingId) {
      contact.id = State.editingId;
      // Preserve createdAt
      const old = State.contacts.find(c => c.id === State.editingId);
      if (old) contact.createdAt = old.createdAt;
      await updateContact(contact);
      showToast('Contact updated ✓', 'success');
    } else {
      await addContact(contact);
      showToast('Contact saved ✓', 'success');
    }

    hideContactForm();
    $('rawCardText').value = '';
    $('rawTextContainer').style.display = 'none';

    await loadContacts();
    setSetting('contact_count', State.contacts.length);

    // Switch to contacts page
    navigateTo('contacts');
  } catch (err) {
    console.error(err);
    showToast('Failed to save contact.', 'error');
  }
}

/* ─────────────────────────────────────────
   CONTACTS LIST
   ───────────────────────────────────────── */
async function loadContacts() {
  State.contacts = await getAllContacts();
  State.contacts.sort((a,b) => (a.name||'').localeCompare(b.name||''));
  applyFilter();
}

function applyFilter() {
  State.filtered = filterContacts(State.contacts, State.searchQuery, State.filterCategory);
  if (State.currentPage === 'contacts') renderContacts();
}

function renderContacts() {
  const list = $('contactsList');
  if (!list) return;

  if (!State.filtered.length) {
    list.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">📭</div>
        <div class="empty-title">${State.contacts.length ? 'No results found' : 'No contacts yet'}</div>
        <div class="empty-sub">${State.contacts.length ? 'Try a different search or filter.' : 'Scan a visiting card or add a contact manually.'}</div>
      </div>`;
    return;
  }

  list.innerHTML = State.filtered.map(c => contactCardHTML(c)).join('');

  // Event listeners
  list.querySelectorAll('.contact-card').forEach(card => {
    const id = +card.dataset.id;

    if (State.bulkMode) {
      card.addEventListener('click', () => toggleSelect(id, card));
    } else {
      card.addEventListener('click', () => openDetail(id));
      card.querySelector('.btn-edit')?.addEventListener('click', e => { e.stopPropagation(); openEdit(id); });
      card.querySelector('.btn-delete')?.addEventListener('click', e => { e.stopPropagation(); confirmDelete(id); });
    }

    if (State.selected.has(id)) card.classList.add('selected');
  });
}

function contactCardHTML(c) {
  const badge = `<span class="contact-badge ${categoryBadgeClass(c.category)}">${escapeHTML(c.category||'')}</span>`;
  return `
    <div class="contact-card" data-id="${c.id}">
      ${State.bulkMode ? `<div class="select-checkbox">${State.selected.has(c.id)?'✓':''}</div>` : ''}
      <div class="contact-avatar ${avatarColor(c.name)}">${avatarLetter(c.name)}</div>
      <div class="contact-info">
        <div class="contact-name">${escapeHTML(c.name||'(No Name)')}</div>
        <div class="contact-sub">${escapeHTML(c.designation ? c.designation + (c.company ? ' · ' + c.company : '') : (c.company||''))}</div>
        <div class="contact-phone">${escapeHTML(formatPhoneDisplay(c.phone))}</div>
      </div>
      ${badge}
      ${!State.bulkMode ? `
      <div class="contact-card-actions">
        <button class="card-action-btn btn-edit" title="Edit">✏️</button>
        <button class="card-action-btn btn-delete" title="Delete">🗑️</button>
      </div>` : ''}
    </div>`;
}

/* ─────────────────────────────────────────
   DETAIL MODAL
   ───────────────────────────────────────── */
function openDetail(id) {
  const c = State.contacts.find(c => c.id === id);
  if (!c) return;
  State.detailId = id;

  const m = $('detailModal');
  m.innerHTML = `
    <div class="modal-handle"></div>
    <div class="detail-header">
      <div class="detail-avatar ${avatarColor(c.name)}">${avatarLetter(c.name)}</div>
      <div>
        <div class="detail-name">${escapeHTML(c.name||'(No Name)')}</div>
        <div class="detail-role">${escapeHTML([c.designation, c.company].filter(Boolean).join(' · '))}</div>
        <span class="contact-badge ${categoryBadgeClass(c.category)}" style="display:inline-block;margin-top:6px">${escapeHTML(c.category||'')}</span>
      </div>
    </div>

    <div class="detail-quick-actions">
      ${c.phone ? `<button class="quick-action call" onclick="window.location='tel:${escapeHTML(c.phone)}'">📞 Call</button>` : ''}
      ${c.email ? `<button class="quick-action mail" onclick="window.location='mailto:${escapeHTML(c.email)}'">✉️ Email</button>` : ''}
      <button class="quick-action" onclick="downloadVCard(State.contacts.find(c=>c.id===${id}));showToast('vCard downloaded','success')">💾 Save to Phone</button>
    </div>

    <div class="detail-fields">
      ${detailField('📞','Phone',    c.phone    ? `<a href="tel:${escapeHTML(c.phone)}">${escapeHTML(c.phone)}</a>` : null)}
      ${detailField('✉️','Email',    c.email    ? `<a href="mailto:${escapeHTML(c.email)}">${escapeHTML(c.email)}</a>` : null)}
      ${detailField('🌐','Website',  c.website  ? `<a href="${escapeHTML(c.website)}" target="_blank">${escapeHTML(c.website)}</a>` : null)}
      ${detailField('🏢','Company',  c.company)}
      ${detailField('💼','Title',    c.designation)}
      ${detailField('📍','Address',  c.address)}
      ${detailField('📅','Added',    formatDate(c.createdAt))}
    </div>

    <div class="modal-actions">
      <button class="btn btn-secondary" style="flex:1" onclick="closeModal('detailOverlay')">Close</button>
      <button class="btn btn-primary"   style="flex:1" onclick="closeModal('detailOverlay');openEdit(${id})">✏️ Edit</button>
      <button class="btn btn-danger"    style="flex:1" onclick="closeModal('detailOverlay');confirmDelete(${id})">🗑️</button>
    </div>
  `;

  $('detailOverlay').classList.remove('hidden');
}

function detailField(icon, label, value) {
  if (!value) return '';
  return `
    <div class="detail-field">
      <div class="detail-field-icon">${icon}</div>
      <div class="detail-field-content">
        <div class="detail-field-label">${label}</div>
        <div class="detail-field-value">${value}</div>
      </div>
    </div>`;
}

/* ─────────────────────────────────────────
   EDIT / DELETE
   ───────────────────────────────────────── */
function openEdit(id) {
  const c = State.contacts.find(c => c.id === id);
  if (!c) return;

  navigateTo('scan');
  setTimeout(() => {
    $('rawTextContainer').style.display = 'none';
    showContactForm(c, id);
  }, 100);
}

function confirmDelete(id) {
  const c = State.contacts.find(c => c.id === id);
  if (!c) return;

  $('confirmIcon').textContent  = '🗑️';
  $('confirmTitle').textContent = 'Delete Contact?';
  $('confirmMsg').textContent   = `"${c.name||'This contact'}" will be permanently removed.`;
  $('confirmOk').onclick = async () => {
    $('confirmDialog').classList.add('hidden');
    await deleteContact(id);
    await loadContacts();
    setSetting('contact_count', State.contacts.length);
    showToast('Contact deleted.', 'info');
  };
  $('confirmCancel').onclick = () => $('confirmDialog').classList.add('hidden');
  $('confirmDialog').classList.remove('hidden');
}

function closeModal(id) { $(id).classList.add('hidden'); }

/* ─────────────────────────────────────────
   BULK MODE
   ───────────────────────────────────────── */
function toggleBulkMode() {
  State.bulkMode = !State.bulkMode;
  State.selected.clear();
  $('bulkBar').classList.toggle('active', State.bulkMode);
  $('bulkCount').textContent = '0 selected';
  renderContacts();
}

function toggleSelect(id, card) {
  if (State.selected.has(id)) {
    State.selected.delete(id);
    card.classList.remove('selected');
    card.querySelector('.select-checkbox').textContent = '';
  } else {
    State.selected.add(id);
    card.classList.add('selected');
    card.querySelector('.select-checkbox').textContent = '✓';
  }
  $('bulkCount').textContent = `${State.selected.size} selected`;
}

async function bulkDelete() {
  if (!State.selected.size) { showToast('Select contacts first.', 'error'); return; }

  $('confirmIcon').textContent  = '⚠️';
  $('confirmTitle').textContent = `Delete ${State.selected.size} contacts?`;
  $('confirmMsg').textContent   = 'This cannot be undone.';
  $('confirmOk').onclick = async () => {
    $('confirmDialog').classList.add('hidden');
    for (const id of State.selected) await deleteContact(id);
    State.selected.clear();
    toggleBulkMode();
    await loadContacts();
    setSetting('contact_count', State.contacts.length);
    showToast('Contacts deleted.', 'info');
  };
  $('confirmCancel').onclick = () => $('confirmDialog').classList.add('hidden');
  $('confirmDialog').classList.remove('hidden');
}

/* ─────────────────────────────────────────
   STATS PAGE
   ───────────────────────────────────────── */
function renderStats() {
  const total    = State.contacts.length;
  const catStats = getCategoryStats(State.contacts);
  const cats     = Object.keys(catStats);
  const max      = Math.max(...Object.values(catStats), 1);

  $('statTotal').textContent = total;

  // Top category
  const topCat = cats.sort((a,b) => catStats[b]-catStats[a])[0] || '—';
  $('statTopCat').textContent = topCat;

  // This week
  const weekAgo = Date.now() - 7*24*3600*1000;
  const thisWeek = State.contacts.filter(c => new Date(c.createdAt).getTime() > weekAgo).length;
  $('statWeek').textContent = thisWeek;

  // Category breakdown
  const barsEl = $('categoryBars');
  barsEl.innerHTML = cats.map((cat, i) => `
    <div class="cat-bar-item">
      <div class="cat-bar-header">
        <span>${escapeHTML(cat)}</span>
        <span style="font-weight:600;color:var(--text-sub)">${catStats[cat]}</span>
      </div>
      <div class="cat-bar-track">
        <div class="cat-bar-fill" style="width:${Math.round(catStats[cat]/max*100)}%;background:${categoryColor(cat,i)}"></div>
      </div>
    </div>
  `).join('');

  if (!cats.length) {
    barsEl.innerHTML = '<div class="empty-sub" style="text-align:center;padding:20px">No data yet.</div>';
  }
}

/* ─────────────────────────────────────────
   CATEGORIES PAGE
   ───────────────────────────────────────── */
function renderCategories() {
  const cats     = getCategories();
  const catStats = getCategoryStats(State.contacts);
  const list     = $('categoryList');

  list.innerHTML = cats.map((cat, i) => `
    <div class="category-item" data-cat="${escapeHTML(cat)}">
      <div class="category-dot" style="background:${categoryColor(cat,i)}"></div>
      <div class="category-name">${escapeHTML(cat)}</div>
      <div class="category-count">${catStats[cat]||0} contacts</div>
      <div class="category-actions">
        <button class="cat-btn btn-rename-cat" title="Rename">✏️</button>
        <button class="cat-btn btn-del-cat" title="Delete">🗑️</button>
      </div>
    </div>
  `).join('');

  list.querySelectorAll('.btn-rename-cat').forEach(btn => {
    btn.addEventListener('click', () => {
      const cat  = btn.closest('[data-cat]').dataset.cat;
      const name = prompt(`Rename "${cat}" to:`, cat);
      if (name && name.trim() && name !== cat) {
        renameCategory(cat, name.trim());
        showToast('Category renamed.', 'success');
        renderCategories();
        populateCategorySelects();
      }
    });
  });

  list.querySelectorAll('.btn-del-cat').forEach(btn => {
    btn.addEventListener('click', () => {
      const cat = btn.closest('[data-cat]').dataset.cat;
      $('confirmIcon').textContent  = '🗂️';
      $('confirmTitle').textContent = `Delete "${cat}"?`;
      $('confirmMsg').textContent   = 'Contacts in this category will become uncategorized.';
      $('confirmOk').onclick = async () => {
        $('confirmDialog').classList.add('hidden');
        removeCategory(cat);
        renderCategories();
        populateCategorySelects();
        showToast('Category deleted.', 'info');
      };
      $('confirmCancel').onclick = () => $('confirmDialog').classList.add('hidden');
      $('confirmDialog').classList.remove('hidden');
    });
  });
}

function addNewCategory() {
  const name = prompt('New category name:');
  if (name && name.trim()) {
    addCategory(name.trim());
    renderCategories();
    populateCategorySelects();
    showToast('Category added.', 'success');
  }
}

/* ─────────────────────────────────────────
   IMPORT / EXPORT
   ───────────────────────────────────────── */
async function exportCSV() {
  if (!State.contacts.length) { showToast('No contacts to export.', 'error'); return; }
  downloadCSV(State.contacts);
  showToast(`Exported ${State.contacts.length} contacts.`, 'success');
  markBackupShown();
}

function triggerCSVImport() { $('csvImportInput').click(); }

async function handleCSVImport(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = async ev => {
    try {
      const parsed   = parseCSV(ev.target.result);
      const imported = await bulkImportContacts(parsed);
      await loadContacts();
      setSetting('contact_count', State.contacts.length);
      showToast(`Imported ${imported} new contacts (${parsed.length - imported} duplicates skipped).`, 'success', 4000);
    } catch (err) {
      console.error(err);
      showToast('Import failed. Check CSV format.', 'error');
    }
  };
  reader.readAsText(file);
  e.target.value = '';
}

function addManualContact() {
  navigateTo('scan');
  setTimeout(() => {
    $('rawTextContainer').style.display = 'none';
    showContactForm({}, null);
  }, 100);
}

/* ─────────────────────────────────────────
   BACKUP BANNER
   ───────────────────────────────────────── */
function checkBackupReminder() {
  if (shouldShowBackupReminder()) {
    const banner = $('backupBanner');
    if (banner) banner.style.display = 'flex';
  }
}

/* ─────────────────────────────────────────
   SEARCH & FILTER
   ───────────────────────────────────────── */
const debouncedSearch = debounce(val => {
  State.searchQuery = val;
  applyFilter();
}, 250);

function setupSearchFilter() {
  const searchEl = $('searchInput');
  const filterEl = $('filterCategory');

  if (searchEl) {
    searchEl.addEventListener('input', e => debouncedSearch(e.target.value));
  }

  if (filterEl) {
    // Populate with categories + "All"
    const cats = ['All', ...getCategories()];
    filterEl.innerHTML = cats.map(c => `<option>${c}</option>`).join('');
    filterEl.addEventListener('change', e => {
      State.filterCategory = e.target.value;
      applyFilter();
    });
  }
}

/* ─────────────────────────────────────────
   PWA REGISTRATION
   ───────────────────────────────────────── */
function registerSW() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./service-worker.js').catch(err => {
      console.warn('SW registration failed:', err);
    });
  }
}

/* ─────────────────────────────────────────
   INIT
   ───────────────────────────────────────── */
async function init() {
  registerSW();
  await loadContacts();
  setSetting('contact_count', State.contacts.length);

  // Bottom nav
  qsa('.nav-item').forEach(item => {
    item.addEventListener('click', () => navigateTo(item.dataset.page));
  });

  // FAB
  $('fab')?.addEventListener('click', addManualContact);

  // Scan page
  $('btnStartCamera')?.addEventListener('click', startCamera);
  $('btnCapture')?.addEventListener('click', captureFrame);
  $('btnRetake')?.addEventListener('click', retakePhoto);
  $('btnGallery')?.addEventListener('click', () => $('galleryInput').click());
  $('galleryInput')?.addEventListener('change', handleGalleryUpload);
  $('btnExtract')?.addEventListener('click', extractAndShowForm);
  $('btnSaveContact')?.addEventListener('click', saveContact);
  $('btnCancelForm')?.addEventListener('click', hideContactForm);
  $('btnAddManual')?.addEventListener('click', addManualContact);

  // Contacts page
  setupSearchFilter();
  $('btnBulkMode')?.addEventListener('click', toggleBulkMode);
  $('btnBulkDelete')?.addEventListener('click', bulkDelete);
  $('btnBulkCancel')?.addEventListener('click', toggleBulkMode);

  // Backup banner
  $('backupBannerClose')?.addEventListener('click', () => {
    $('backupBanner').style.display = 'none';
    markBackupShown();
  });
  $('backupBannerExport')?.addEventListener('click', () => {
    $('backupBanner').style.display = 'none';
    markBackupShown();
    exportCSV();
  });

  // Import/Export
  $('btnExportCSV')?.addEventListener('click', exportCSV);
  $('btnImportCSV')?.addEventListener('click', triggerCSVImport);
  $('csvImportInput')?.addEventListener('change', handleCSVImport);

  // Categories
  $('btnAddCategory')?.addEventListener('click', addNewCategory);

  // Confirm dialog
  $('confirmCancel')?.addEventListener('click', () => $('confirmDialog').classList.add('hidden'));

  // Modal overlay click to close
  $('detailOverlay')?.addEventListener('click', e => {
    if (e.target === $('detailOverlay')) closeModal('detailOverlay');
  });

  // Category select in form
  populateCategorySelects();
  setupSearchFilter();

  // Navigate to scan by default
  navigateTo('scan');

  // Check backup reminder
  setTimeout(checkBackupReminder, 1500);
}

document.addEventListener('DOMContentLoaded', init);

/* ─────────────────────────────────────────
   utils.js  –  Utility Functions for VC Contacts PRO
   ───────────────────────────────────────── */

/* ── Category Management (localStorage) ── */

const DEFAULT_CATEGORIES = [
  'Business', 'Education', 'Medical', 'Government', 'Personal', 'Services'
];

function getCategories() {
  try {
    const stored = localStorage.getItem('vc_categories');
    return stored ? JSON.parse(stored) : [...DEFAULT_CATEGORIES];
  } catch { return [...DEFAULT_CATEGORIES]; }
}

function saveCategories(cats) {
  localStorage.setItem('vc_categories', JSON.stringify(cats));
}

function addCategory(name) {
  const cats = getCategories();
  if (!cats.includes(name)) { cats.push(name); saveCategories(cats); }
  return cats;
}

function removeCategory(name) {
  const cats = getCategories().filter(c => c !== name);
  saveCategories(cats);
  return cats;
}

function renameCategory(oldName, newName) {
  const cats = getCategories().map(c => c === oldName ? newName : c);
  saveCategories(cats);
  return cats;
}

/* ── CSV Export ── */

function contactsToCSV(contacts) {
  const headers = ['Name','Phone','Email','Company','Designation','Address','Website','Category','Created At'];
  const rows = contacts.map(c => [
    c.name, c.phone, c.email, c.company, c.designation,
    c.address, c.website, c.category,
    c.createdAt ? new Date(c.createdAt).toLocaleDateString() : ''
  ].map(v => `"${(v||'').replace(/"/g,'""')}"`));

  return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
}

function downloadCSV(contacts, filename = 'vc-contacts-export.csv') {
  const csv  = contactsToCSV(contacts);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  downloadBlob(blob, filename);
}

/* ── CSV Import ── */

function parseCSV(text) {
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  if (lines.length < 2) return [];

  const headers = lines[0].split(',').map(h => h.replace(/^"|"$/g,'').trim().toLowerCase());
  return lines.slice(1).map(line => {
    const values = parseCSVLine(line);
    const obj    = {};
    headers.forEach((h, i) => { obj[h] = (values[i] || '').replace(/^"|"$/g,'').trim(); });
    return {
      name:        obj.name        || '',
      phone:       obj.phone       || '',
      email:       obj.email       || '',
      company:     obj.company     || '',
      designation: obj.designation || '',
      address:     obj.address     || '',
      website:     obj.website     || '',
      category:    obj.category    || 'Business'
    };
  }).filter(c => c.name || c.phone || c.email);
}

function parseCSVLine(line) {
  const result = []; let cur = ''; let inQ = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQ && line[i+1] === '"') { cur += '"'; i++; }
      else inQ = !inQ;
    } else if (ch === ',' && !inQ) { result.push(cur); cur = ''; }
    else cur += ch;
  }
  result.push(cur);
  return result;
}

/* ── vCard Export ── */

function contactToVCard(c) {
  return [
    'BEGIN:VCARD',
    'VERSION:3.0',
    `FN:${c.name || ''}`,
    `N:${(c.name||'').split(' ').reverse().join(';')};;;`,
    c.phone  ? `TEL;TYPE=CELL:${c.phone}` : '',
    c.email  ? `EMAIL:${c.email}` : '',
    c.company     ? `ORG:${c.company}` : '',
    c.designation ? `TITLE:${c.designation}` : '',
    c.address     ? `ADR;TYPE=WORK:;;${c.address};;;;` : '',
    c.website     ? `URL:${c.website}` : '',
    'END:VCARD'
  ].filter(Boolean).join('\r\n');
}

function downloadVCard(contact) {
  const vcf  = contactToVCard(contact);
  const blob = new Blob([vcf], { type: 'text/vcard;charset=utf-8;' });
  const name = (contact.name || 'contact').replace(/\s+/g, '_');
  downloadBlob(blob, `${name}.vcf`);
}

/* ── Blob Download Helper ── */

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a   = document.createElement('a');
  a.href     = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(url); }, 100);
}

/* ── Phone Formatting ── */

function formatPhoneDisplay(phone) {
  if (!phone) return '';
  const digits = phone.replace(/\D/g, '');
  if (digits.length === 10) return `${digits.slice(0,5)} ${digits.slice(5)}`;
  return phone;
}

/* ── Date Formatting ── */

function formatDate(iso) {
  if (!iso) return '';
  return new Date(iso).toLocaleDateString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric'
  });
}

/* ── Settings (localStorage) ── */

function getSetting(key, fallback = null) {
  try {
    const v = localStorage.getItem(`vc_${key}`);
    return v !== null ? JSON.parse(v) : fallback;
  } catch { return fallback; }
}

function setSetting(key, value) {
  localStorage.setItem(`vc_${key}`, JSON.stringify(value));
}

/* ── Backup reminder ── */

function shouldShowBackupReminder() {
  const last     = getSetting('last_backup_prompt', 0);
  const contacts = getSetting('contact_count', 0);
  const now      = Date.now();
  const WEEK_MS  = 7 * 24 * 60 * 60 * 1000;
  return contacts > 5 && (now - last) > WEEK_MS;
}

function markBackupShown() {
  setSetting('last_backup_prompt', Date.now());
}

/* ── Search/Filter ── */

function filterContacts(contacts, query, category) {
  let result = [...contacts];

  if (category && category !== 'All') {
    result = result.filter(c => c.category === category);
  }

  if (query && query.trim()) {
    const q = query.toLowerCase().trim();
    result = result.filter(c =>
      (c.name        || '').toLowerCase().includes(q) ||
      (c.phone       || '').includes(q)               ||
      (c.email       || '').toLowerCase().includes(q) ||
      (c.company     || '').toLowerCase().includes(q) ||
      (c.designation || '').toLowerCase().includes(q)
    );
  }

  return result;
}

/* ── Category Statistics ── */

function getCategoryStats(contacts) {
  const stats = {};
  contacts.forEach(c => {
    const cat = c.category || 'Uncategorized';
    stats[cat] = (stats[cat] || 0) + 1;
  });
  return stats;
}

/* ── Debounce ── */

function debounce(fn, delay = 300) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

/* ── Toast Notification ── */

function showToast(message, type = 'info', duration = 3000) {
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <span class="toast-icon">${type === 'success' ? '✓' : type === 'error' ? '✕' : 'ℹ'}</span>
    <span class="toast-msg">${message}</span>
  `;
  document.body.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add('show'));
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

/* ── Sanitize HTML ── */

function escapeHTML(str) {
  return (str || '')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

/* ── Generate SVG icon as data URI (for PWA icons) ── */
function generateIconSVG(size) {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
    <rect width="${size}" height="${size}" rx="${size*0.2}" fill="#2E7D32"/>
    <text x="50%" y="58%" font-size="${size*0.55}" text-anchor="middle" dominant-baseline="middle" fill="#fff" font-family="sans-serif" font-weight="bold">VC</text>
  </svg>`;
}

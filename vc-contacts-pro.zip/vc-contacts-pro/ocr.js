/* ─────────────────────────────────────────
   ocr.js  –  Intelligent Data Extraction Engine
   Uses regex + heuristics for visiting card parsing
   ───────────────────────────────────────── */

/* ── Regex Patterns ── */
const PATTERNS = {
  email:   /\b[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}\b/gi,
  phone:   /(\+?[\d\s\-().]{7,15}\d)/g,
  website: /(https?:\/\/[^\s]+|www\.[^\s]+\.[a-z]{2,}[^\s]*)/gi,
  pincode: /\b\d{6}\b/g,
};

/* ── Designation / Title keywords ── */
const DESIGNATION_KEYWORDS = [
  'ceo', 'cto', 'cfo', 'coo', 'founder', 'co-founder', 'director',
  'manager', 'engineer', 'developer', 'analyst', 'consultant',
  'officer', 'president', 'vice president', 'vp', 'head',
  'associate', 'executive', 'coordinator', 'specialist', 'architect',
  'lead', 'senior', 'junior', 'intern', 'professor', 'dr', 'doctor',
  'principal', 'partner', 'proprietor', 'owner', 'chairman'
];

/* ── Company keywords ── */
const COMPANY_KEYWORDS = [
  'pvt', 'ltd', 'llc', 'inc', 'corp', 'company', 'co.', 'solutions',
  'technologies', 'tech', 'services', 'group', 'associates',
  'industries', 'enterprises', 'foundation', 'institute', 'university',
  'college', 'hospital', 'clinic', 'school', 'academy', 'international'
];

/* ── Address keywords ── */
const ADDRESS_KEYWORDS = [
  'road', 'street', 'st.', 'avenue', 'ave', 'lane', 'nagar',
  'colony', 'sector', 'phase', 'plot', 'flat', 'floor', 'building',
  'complex', 'near', 'behind', 'opposite', 'opp.', 'district',
  'taluk', 'city', 'state', 'india', 'mumbai', 'delhi', 'pune',
  'bangalore', 'hyderabad', 'chennai', 'kolkata'
];

/**
 * Main extraction function.
 * @param {string} rawText - Raw text from card (manual input or OCR result)
 * @returns {Object} Structured contact object
 */
function extractContactData(rawText) {
  if (!rawText || !rawText.trim()) return emptyContact();

  // Split into lines and clean
  const lines = rawText
    .split(/\n|;/)
    .map(l => l.trim())
    .filter(l => l.length > 0);

  const result = emptyContact();
  const usedLines = new Set();

  /* ── Step 1: Extract definitive patterns ── */

  // Email
  const emailMatches = rawText.match(PATTERNS.email);
  if (emailMatches) {
    result.email = emailMatches[0].toLowerCase();
    markUsed(lines, usedLines, emailMatches[0]);
  }

  // Website
  const webMatches = rawText.match(PATTERNS.website);
  if (webMatches) {
    result.website = webMatches[0];
    markUsed(lines, usedLines, webMatches[0]);
  }

  // Phone — pick the most likely phone number
  const phoneMatches = rawText.match(PATTERNS.phone);
  if (phoneMatches) {
    const cleaned = phoneMatches
      .map(p => p.replace(/[^\d+]/g, ''))
      .filter(p => p.length >= 7 && p.length <= 15);
    if (cleaned.length) {
      result.phone = formatPhone(cleaned[0]);
      markUsed(lines, usedLines, phoneMatches[0]);
    }
  }

  /* ── Step 2: Heuristic line classification ── */
  for (let i = 0; i < lines.length; i++) {
    if (usedLines.has(i)) continue;

    const line    = lines[i];
    const lower   = line.toLowerCase();
    const wordCnt = line.split(/\s+/).length;

    // Skip lines already consumed as email/phone/web
    if (
      PATTERNS.email.test(line) ||
      PATTERNS.website.test(line) ||
      isPhoneLine(line)
    ) {
      usedLines.add(i);
      // Reset lastIndex
      PATTERNS.email.lastIndex  = 0;
      PATTERNS.website.lastIndex = 0;
      continue;
    }

    // Name: typically the FIRST unused line, ≤ 4 words, mostly capitalized
    if (!result.name && isNameLike(line, wordCnt)) {
      result.name = toTitleCase(line);
      usedLines.add(i);
      continue;
    }

    // Designation
    if (!result.designation && containsAny(lower, DESIGNATION_KEYWORDS)) {
      result.designation = toTitleCase(line);
      usedLines.add(i);
      continue;
    }

    // Company
    if (!result.company && containsAny(lower, COMPANY_KEYWORDS)) {
      result.company = toTitleCase(line);
      usedLines.add(i);
      continue;
    }

    // Address
    if (containsAny(lower, ADDRESS_KEYWORDS) || PATTERNS.pincode.test(line)) {
      result.address += (result.address ? ', ' : '') + line;
      usedLines.add(i);
      PATTERNS.pincode.lastIndex = 0;
      continue;
    }
  }

  /* ── Step 3: Second-pass for remaining lines ── */
  for (let i = 0; i < lines.length; i++) {
    if (usedLines.has(i)) continue;
    const line  = lines[i];
    const lower = line.toLowerCase();

    if (!result.company && line.length > 3) {
      result.company = toTitleCase(line);
      usedLines.add(i);
    } else if (!result.address) {
      result.address = line;
      usedLines.add(i);
    }
  }

  return result;
}

/* ── Helper Functions ── */

function emptyContact() {
  return {
    name: '', phone: '', email: '',
    company: '', designation: '', address: '', website: ''
  };
}

function markUsed(lines, usedLines, text) {
  lines.forEach((line, i) => {
    if (line.includes(text) || text.includes(line)) usedLines.add(i);
  });
}

function containsAny(str, keywords) {
  return keywords.some(kw => str.includes(kw));
}

function isNameLike(line, wordCnt) {
  // ≤ 5 words, no digits, no special chars except . and -
  return wordCnt <= 5 &&
    !/\d/.test(line) &&
    !/[@#$%^&*()_+=[\]{};:'",<>/?\\|]/.test(line) &&
    line.length > 1 &&
    line.length < 60;
}

function isPhoneLine(line) {
  const digits = line.replace(/\D/g, '');
  return digits.length >= 7 && digits.length <= 15 &&
    (line.replace(/[\d\s\-+().]/g, '').length < 3);
}

function toTitleCase(str) {
  return str.replace(/\w\S*/g, w =>
    w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()
  );
}

function formatPhone(phone) {
  // Format Indian numbers: +91-XXXXX-XXXXX
  const digits = phone.replace(/\D/g, '');
  if (digits.length === 10) return `+91-${digits.slice(0,5)}-${digits.slice(5)}`;
  if (digits.length === 12 && digits.startsWith('91')) {
    return `+91-${digits.slice(2,7)}-${digits.slice(7)}`;
  }
  return phone;
}

/**
 * Confidence score (0–100) for how complete an extraction is.
 */
function extractionConfidence(contact) {
  const fields = ['name','phone','email','company','designation','address'];
  const filled = fields.filter(f => contact[f] && contact[f].trim()).length;
  return Math.round((filled / fields.length) * 100);
}

/* ─────────────────────────────────────────
   db.js  –  IndexedDB wrapper for VC Contacts PRO
   Database: VCContactsDB  |  Store: contacts
   ───────────────────────────────────────── */

const DB_NAME    = 'VCContactsDB';
const DB_VERSION = 1;
const STORE_NAME = 'contacts';

let _db = null;

/**
 * Open (or create) the IndexedDB database.
 * @returns {Promise<IDBDatabase>}
 */
function openDB() {
  return new Promise((resolve, reject) => {
    if (_db) { resolve(_db); return; }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = e => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('name',      'name',      { unique: false });
        store.createIndex('phone',     'phone',     { unique: false });
        store.createIndex('email',     'email',     { unique: false });
        store.createIndex('category',  'category',  { unique: false });
        store.createIndex('createdAt', 'createdAt', { unique: false });
      }
    };

    request.onsuccess = e => { _db = e.target.result; resolve(_db); };
    request.onerror   = e => reject(e.target.error);
  });
}

/**
 * Execute a transaction against the contacts store.
 * @param {'readonly'|'readwrite'} mode
 * @param {Function} fn  receives (store) and must return a request or value
 */
function tx(mode, fn) {
  return openDB().then(db => new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, mode);
    const store       = transaction.objectStore(STORE_NAME);
    const result      = fn(store);

    if (result && typeof result.onsuccess !== 'undefined') {
      result.onsuccess = e => resolve(e.target.result);
      result.onerror   = e => reject(e.target.error);
    } else {
      transaction.oncomplete = () => resolve(result);
      transaction.onerror    = e => reject(e.target.error);
    }
  }));
}

/* ── CRUD Operations ── */

/** Add a new contact. Returns the new id. */
function addContact(contact) {
  contact.id        = Date.now();
  contact.createdAt = new Date().toISOString();
  return tx('readwrite', store => store.add(contact)).then(() => contact.id);
}

/** Update an existing contact. */
function updateContact(contact) {
  return tx('readwrite', store => store.put(contact));
}

/** Delete a contact by id. */
function deleteContact(id) {
  return tx('readwrite', store => store.delete(id));
}

/** Get a single contact by id. */
function getContact(id) {
  return tx('readonly', store => store.get(id));
}

/** Get ALL contacts as an array. */
function getAllContacts() {
  return openDB().then(db => new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readonly');
    const store       = transaction.objectStore(STORE_NAME);
    const request     = store.getAll();
    request.onsuccess = e => resolve(e.target.result);
    request.onerror   = e => reject(e.target.error);
  }));
}

/** Bulk-import an array of contacts (skips duplicates by phone/email). */
async function bulkImportContacts(contacts) {
  const existing = await getAllContacts();
  const phones   = new Set(existing.map(c => c.phone).filter(Boolean));
  const emails   = new Set(existing.map(c => c.email).filter(Boolean));

  let imported = 0;
  for (const c of contacts) {
    const isDup = (c.phone && phones.has(c.phone)) ||
                  (c.email && emails.has(c.email));
    if (!isDup) {
      await addContact(c);
      if (c.phone) phones.add(c.phone);
      if (c.email) emails.add(c.email);
      imported++;
    }
  }
  return imported;
}

/** Check whether a phone or email already exists. */
async function isDuplicate(phone, email) {
  const all = await getAllContacts();
  return all.some(c =>
    (phone && c.phone === phone) ||
    (email && c.email === email)
  );
}

/** Delete all contacts (bulk clear). */
function clearAllContacts() {
  return tx('readwrite', store => store.clear());
}
